function main(){
    // var sprite = renderSprite(smoothedRoot);
	// renderText("Full description \nof the item", sprite);    
    //renderBox(smoothedRoot);
     renderObject(smoothedRoot, "data/models/model4.json");
     // renderObject(smoothedRoot, "http://ar-test-api.surge.sh/tree.json");
    // renderObject(smoothedRoot, "data/models/scene.json");
    
}

